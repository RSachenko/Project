fun main(args: Array<String>) {

        print("Имя посетителя: ")
        val name = readLine()
        print("Фамилию посетителя: ")
        val seName = readLine()
        print("Возраст посетителя " )
        val age = readLine().toString()
        val a = age.toInt ()
        if (a>=18)
            println("Посетителя $name $seName пропустить в торговый центр")
        else
            if (a<14)
                println("Вызвать полицию для $name $seName")
        else
            if (a>=14)
                println("$name $seName не пропускать в торговый центр")
}
